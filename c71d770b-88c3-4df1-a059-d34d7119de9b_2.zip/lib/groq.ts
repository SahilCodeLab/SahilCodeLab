export const GROQ_API_KEY = "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";

export interface GroqMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export async function generateSolution(problem: string, category: string): Promise<string> {
  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GROQ_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'llama3-8b-8192',
        messages: [
          {
            role: 'system',
            content: `You are an expert problem solver. Provide detailed, practical solutions for problems in the ${category} category. Give step-by-step actionable advice that is helpful and realistic.`
          },
          {
            role: 'user',
            content: `Problem: ${problem}. Please provide a comprehensive solution with specific steps and recommendations.`
          }
        ],
        temperature: 0.7,
        max_tokens: 1000,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to generate solution');
    }

    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error('Error generating solution:', error);
    return 'Unable to generate solution at this time. Please try again later.';
  }
}

export async function generateRelatedQuestions(problem: string): Promise<string[]> {
  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GROQ_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'llama3-8b-8192',
        messages: [
          {
            role: 'system',
            content: 'Generate 3 related questions based on the given problem. Return only the questions, one per line.'
          },
          {
            role: 'user',
            content: `Problem: ${problem}`
          }
        ],
        temperature: 0.8,
        max_tokens: 200,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to generate related questions');
    }

    const data = await response.json();
    return data.choices[0].message.content.split('\n').filter((q: string) => q.trim());
  } catch (error) {
    console.error('Error generating related questions:', error);
    return [];
  }
}