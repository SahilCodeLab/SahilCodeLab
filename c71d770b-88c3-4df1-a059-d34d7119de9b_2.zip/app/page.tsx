'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');

  const problemCategories = [
    {
      icon: 'ri-heart-line',
      title: 'Relationship & Family',
      description: 'Marriage, dating, parenting, friendship issues',
      color: 'bg-pink-50 border-pink-200',
      href: '/relationship'
    },
    {
      icon: 'ri-briefcase-line',
      title: 'Career & Work',
      description: 'Job search, workplace conflicts, career changes',
      color: 'bg-blue-50 border-blue-200',
      href: '/career'
    },
    {
      icon: 'ri-heart-pulse-line',
      title: 'Health & Wellness',
      description: 'Physical health, mental health, lifestyle',
      color: 'bg-green-50 border-green-200',
      href: '/health'
    },
    {
      icon: 'ri-coins-line',
      title: 'Finance & Money',
      description: 'Budgeting, investing, debt management',
      color: 'bg-yellow-50 border-yellow-200',
      href: '/finance'
    },
    {
      icon: 'ri-graduation-cap-line',
      title: 'Education & Learning',
      description: 'Study tips, skill development, academic issues',
      color: 'bg-purple-50 border-purple-200',
      href: '/education'
    },
    {
      icon: 'ri-settings-line',
      title: 'Technology & Digital',
      description: 'Software issues, device problems, online safety',
      color: 'bg-indigo-50 border-indigo-200',
      href: '/technology'
    },
    {
      icon: 'ri-scales-line',
      title: 'Legal & Rights',
      description: 'Legal advice, rights protection, procedures',
      color: 'bg-red-50 border-red-200',
      href: '/legal'
    },
    {
      icon: 'ri-home-line',
      title: 'Home & Lifestyle',
      description: 'Home improvement, organization, daily life',
      color: 'bg-orange-50 border-orange-200',
      href: '/home'
    }
  ];

  const recentSolutions = [
    {
      problem: 'How to deal with workplace burnout?',
      category: 'Career',
      views: '2.3k',
      solutions: 15
    },
    {
      problem: 'Managing anxiety during job interviews',
      category: 'Career',
      views: '1.8k',
      solutions: 23
    },
    {
      problem: 'Budgeting for first-time home buyers',
      category: 'Finance',
      views: '3.1k',
      solutions: 18
    },
    {
      problem: 'Improving communication with teenagers',
      category: 'Family',
      views: '1.5k',
      solutions: 12
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <i className="ri-lightbulb-line text-white text-lg"></i>
              </div>
              <h1 className="text-2xl font-bold text-gray-900">SolveAll</h1>
            </div>
            <nav className="hidden md:flex space-x-8">
              <Link href="/solutions" className="text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
                Browse Solutions
              </Link>
              <Link href="/ask" className="text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
                Ask Question
              </Link>
              <Link href="/experts" className="text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
                Find Experts
              </Link>
              <Link href="/about" className="text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
                About
              </Link>
            </nav>
            <div className="flex items-center space-x-4">
              <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                Get Help Now
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4" style={{
        backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20minimalist%20workspace%20with%20soft%20lighting%2C%20people%20collaborating%20and%20solving%20problems%20together%2C%20clean%20white%20background%20with%20subtle%20blue%20accents%2C%20professional%20atmosphere%20with%20books%20and%20technology%2C%20inspiring%20and%20hopeful%20mood%2C%20high%20quality%20photography%20style&width=1200&height=600&seq=hero-bg&orientation=landscape')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}>
        <div className="absolute inset-0 bg-white/80"></div>
        <div className="relative max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Every Problem Has a <span className="text-blue-600">Solution</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
            From relationship issues to career challenges, health concerns to financial planning - 
            find expert solutions to any problem you're facing.
          </p>
          
          {/* Search Bar */}
          <div className="max-w-2xl mx-auto mb-8">
            <div className="relative">
              <input
                type="text"
                placeholder="Describe your problem or search for solutions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-6 py-4 text-lg border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-12"
              />
              <button className="absolute right-3 top-1/2 transform -translate-y-1/2 w-8 h-8 bg-blue-600 text-white rounded-lg flex items-center justify-center hover:bg-blue-700 transition-colors cursor-pointer">
                <i className="ri-search-line text-sm"></i>
              </button>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <span className="text-gray-500">Popular searches:</span>
            <button className="text-blue-600 hover:underline cursor-pointer">Job interview tips</button>
            <button className="text-blue-600 hover:underline cursor-pointer">Relationship advice</button>
            <button className="text-blue-600 hover:underline cursor-pointer">Budget planning</button>
            <button className="text-blue-600 hover:underline cursor-pointer">Stress management</button>
          </div>
        </div>
      </section>

      {/* Problem Categories */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What Type of Problem Are You Facing?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Choose a category to find targeted solutions and expert advice
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {problemCategories.map((category, index) => (
              <Link key={index} href={category.href} className="cursor-pointer">
                <div className={`${category.color} border-2 rounded-xl p-6 hover:shadow-lg transition-all duration-300 hover:scale-105 h-full`}>
                  <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center mb-4">
                    <i className={`${category.icon} text-2xl text-gray-700`}></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{category.title}</h3>
                  <p className="text-gray-600 text-sm">{category.description}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Recent Solutions */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Recently Solved Problems
            </h2>
            <p className="text-xl text-gray-600">
              See how others have found solutions to their challenges
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {recentSolutions.map((solution, index) => (
              <div key={index} className="bg-gray-50 rounded-xl p-6 border border-gray-200 hover:shadow-md transition-shadow cursor-pointer">
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900 flex-1 mr-4">
                    {solution.problem}
                  </h3>
                  <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full whitespace-nowrap">
                    {solution.category}
                  </span>
                </div>
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <div className="flex items-center space-x-1">
                    <i className="ri-eye-line"></i>
                    <span>{solution.views} views</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <i className="ri-chat-1-line"></i>
                    <span>{solution.solutions} solutions</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-8">
            <Link href="/solutions" className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap inline-block">
              View All Solutions
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose SolveAll?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-group-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Expert Community</h3>
              <p className="text-gray-600">
                Connect with verified experts and experienced individuals who've solved similar problems
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-check-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Proven Solutions</h3>
              <p className="text-gray-600">
                All solutions are tested and verified by our community with real success stories
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-time-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">24/7 Support</h3>
              <p className="text-gray-600">
                Get help anytime, anywhere with our round-the-clock community support system
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Solve Your Problem?
          </h2>
          <p className="text-xl mb-8 text-blue-100">
            Join thousands of people who have found solutions to their challenges
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/ask" className="bg-white text-blue-600 px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap inline-block">
              Ask Your Question
            </Link>
            <Link href="/solutions" className="border-2 border-white text-white px-8 py-3 rounded-lg hover:bg-white hover:text-blue-600 transition-colors cursor-pointer whitespace-nowrap inline-block">
              Browse Solutions
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                  <i className="ri-lightbulb-line text-white text-lg"></i>
                </div>
                <h3 className="text-xl font-bold">SolveAll</h3>
              </div>
              <p className="text-gray-400">
                Your one-stop solution platform for every problem life throws at you.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Categories</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/relationship" className="hover:text-white cursor-pointer">Relationship</Link></li>
                <li><Link href="/career" className="hover:text-white cursor-pointer">Career</Link></li>
                <li><Link href="/health" className="hover:text-white cursor-pointer">Health</Link></li>
                <li><Link href="/finance" className="hover:text-white cursor-pointer">Finance</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/help" className="hover:text-white cursor-pointer">Help Center</Link></li>
                <li><Link href="/contact" className="hover:text-white cursor-pointer">Contact Us</Link></li>
                <li><Link href="/guidelines" className="hover:text-white cursor-pointer">Guidelines</Link></li>
                <li><Link href="/privacy" className="hover:text-white cursor-pointer">Privacy Policy</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Connect</h4>
              <div className="flex space-x-4">
                <a href="#" className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                  <i className="ri-facebook-fill"></i>
                </a>
                <a href="#" className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                  <i className="ri-twitter-fill"></i>
                </a>
                <a href="#" className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                  <i className="ri-linkedin-fill"></i>
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 SolveAll. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}