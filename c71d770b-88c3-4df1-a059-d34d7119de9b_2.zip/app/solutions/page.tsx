'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import SolutionCard from '@/components/SolutionCard';
import SearchBar from '@/components/SearchBar';
import FilterTabs from '@/components/FilterTabs';

export default function SolutionsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [filteredSolutions, setFilteredSolutions] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const categories = [
    'All',
    'Relationship',
    'Career',
    'Health',
    'Finance',
    'Education',
    'Technology',
    'Legal',
    'Home'
  ];

  const allSolutions = [
    {
      id: 1,
      problem: 'How to deal with workplace burnout and stress?',
      category: 'Career',
      views: '2.3k',
      solutions: 15,
      description: 'Feeling overwhelmed at work with constant deadlines and pressure'
    },
    {
      id: 2,
      problem: 'Managing anxiety during job interviews',
      category: 'Career',
      views: '1.8k',
      solutions: 23,
      description: 'Getting nervous and unable to perform well in interviews'
    },
    {
      id: 3,
      problem: 'Budgeting for first-time home buyers',
      category: 'Finance',
      views: '3.1k',
      solutions: 18,
      description: 'Need help planning finances for buying my first home'
    },
    {
      id: 4,
      problem: 'Improving communication with teenagers',
      category: 'Relationship',
      views: '1.5k',
      solutions: 12,
      description: 'Struggling to connect and communicate with my teenage children'
    },
    {
      id: 5,
      problem: 'Overcoming social anxiety in public settings',
      category: 'Health',
      views: '2.7k',
      solutions: 31,
      description: 'Feel anxious and uncomfortable in social situations'
    },
    {
      id: 6,
      problem: 'Learning programming as a complete beginner',
      category: 'Education',
      views: '4.2k',
      solutions: 45,
      description: 'Want to start coding but don\'t know where to begin'
    },
    {
      id: 7,
      problem: 'Fixing slow computer performance',
      category: 'Technology',
      views: '1.9k',
      solutions: 28,
      description: 'My computer has become very slow and crashes frequently'
    },
    {
      id: 8,
      problem: 'Dealing with noisy neighbors legally',
      category: 'Legal',
      views: '1.2k',
      solutions: 17,
      description: 'Neighbors are too loud and disturbing my peace'
    },
    {
      id: 9,
      problem: 'Organizing small living spaces effectively',
      category: 'Home',
      views: '2.1k',
      solutions: 22,
      description: 'Need ideas to maximize space in my small apartment'
    },
    {
      id: 10,
      problem: 'Building self-confidence and self-esteem',
      category: 'Health',
      views: '3.8k',
      solutions: 39,
      description: 'Struggling with low self-confidence affecting my daily life'
    },
    {
      id: 11,
      problem: 'Managing debt and improving credit score',
      category: 'Finance',
      views: '2.9k',
      solutions: 26,
      description: 'Need help getting out of debt and fixing my credit'
    },
    {
      id: 12,
      problem: 'Dealing with difficult coworkers',
      category: 'Career',
      views: '2.2k',
      solutions: 19,
      description: 'Having conflicts with colleagues affecting my work'
    }
  ];

  useEffect(() => {
    setIsLoading(true);
    setTimeout(() => {
      let filtered = allSolutions;
      
      if (activeCategory !== 'All') {
        filtered = filtered.filter(solution => solution.category === activeCategory);
      }
      
      if (searchQuery) {
        filtered = filtered.filter(solution => 
          solution.problem.toLowerCase().includes(searchQuery.toLowerCase()) ||
          solution.description.toLowerCase().includes(searchQuery.toLowerCase())
        );
      }
      
      setFilteredSolutions(filtered);
      setIsLoading(false);
    }, 300);
  }, [activeCategory, searchQuery]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleCategoryChange = (category: string) => {
    setActiveCategory(category);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Link href="/" className="flex items-center space-x-2 cursor-pointer">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                  <i className="ri-lightbulb-line text-white text-lg"></i>
                </div>
                <h1 className="text-2xl font-bold text-gray-900">SolveAll</h1>
              </Link>
            </div>
            <nav className="hidden md:flex space-x-8">
              <Link href="/solutions" className="text-blue-600 font-medium cursor-pointer">
                Browse Solutions
              </Link>
              <Link href="/ask" className="text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
                Ask Question
              </Link>
              <Link href="/experts" className="text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
                Find Experts
              </Link>
            </nav>
            <div className="flex items-center space-x-4">
              <Link href="/ask" className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                Ask Question
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 animate-fadeIn">
            Discover <span className="text-blue-600">AI-Powered Solutions</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 animate-fadeIn">
            Search through thousands of problems and get instant AI-generated solutions
          </p>
          
          <div className="animate-slideUp">
            <SearchBar onSearch={handleSearch} placeholder="Search for problems and solutions..." />
          </div>
        </div>
      </section>

      {/* Filter Tabs */}
      <section className="px-4 mb-8">
        <div className="max-w-7xl mx-auto">
          <FilterTabs 
            categories={categories}
            activeCategory={activeCategory}
            onCategoryChange={handleCategoryChange}
          />
        </div>
      </section>

      {/* Solutions Grid */}
      <section className="px-4 pb-16">
        <div className="max-w-7xl mx-auto">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, index) => (
                <div key={index} className="bg-white rounded-xl p-6 border border-gray-200 animate-pulse">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3 mb-4"></div>
                  <div className="flex space-x-2">
                    <div className="h-8 bg-gray-200 rounded w-24"></div>
                    <div className="h-8 bg-gray-200 rounded w-24"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredSolutions.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fadeIn">
              {filteredSolutions.map((solution, index) => (
                <div key={solution.id} className="animate-slideUp" style={{ animationDelay: `${index * 0.1}s` }}>
                  <SolutionCard
                    problem={solution.problem}
                    category={solution.category}
                    views={solution.views}
                    solutions={solution.solutions}
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 animate-fadeIn">
              <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-search-line text-4xl text-gray-400"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No Solutions Found</h3>
              <p className="text-gray-600 mb-4">Try adjusting your search terms or browse different categories</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveCategory('All');
                }}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap"
              >
                Clear Filters
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Community Impact
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: 'ri-question-line', count: '50,000+', label: 'Problems Solved' },
              { icon: 'ri-group-line', count: '15,000+', label: 'Active Users' },
              { icon: 'ri-star-line', count: '98%', label: 'Success Rate' },
              { icon: 'ri-time-line', count: '24/7', label: 'AI Support' }
            ].map((stat, index) => (
              <div key={index} className="text-center animate-fadeIn" style={{ animationDelay: `${index * 0.2}s` }}>
                <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className={`${stat.icon} text-white text-2xl`}></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-1">{stat.count}</h3>
                <p className="text-gray-600">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Can't Find Your Solution?
          </h2>
          <p className="text-xl mb-8 text-blue-100">
            Ask our AI-powered system to generate a personalized solution for your problem
          </p>
          <Link href="/ask" className="bg-white text-blue-600 px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap inline-block font-semibold">
            Ask Your Question Now
          </Link>
        </div>
      </section>
    </div>
  );
}