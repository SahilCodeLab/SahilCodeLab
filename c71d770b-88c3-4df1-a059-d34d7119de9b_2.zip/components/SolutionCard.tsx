'use client';

import { useState } from 'react';
import { generateSolution, generateRelatedQuestions } from '@/lib/groq';

interface SolutionCardProps {
  problem: string;
  category: string;
  views: string;
  solutions: number;
  onSolutionGenerated?: (solution: string) => void;
}

export default function SolutionCard({ 
  problem, 
  category, 
  views, 
  solutions, 
  onSolutionGenerated 
}: SolutionCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [generatedSolution, setGeneratedSolution] = useState('');
  const [relatedQuestions, setRelatedQuestions] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showRelated, setShowRelated] = useState(false);

  const handleGenerateSolution = async () => {
    setIsGenerating(true);
    try {
      const solution = await generateSolution(problem, category);
      const related = await generateRelatedQuestions(problem);
      
      setGeneratedSolution(solution);
      setRelatedQuestions(related);
      setIsExpanded(true);
      
      if (onSolutionGenerated) {
        onSolutionGenerated(solution);
      }
    } catch (error) {
      console.error('Error generating solution:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-all duration-300 transform hover:scale-105">
      <div className="flex items-start justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 flex-1 mr-4">
          {problem}
        </h3>
        <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full whitespace-nowrap">
          {category}
        </span>
      </div>
      
      <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
        <div className="flex items-center space-x-1">
          <i className="ri-eye-line"></i>
          <span>{views} views</span>
        </div>
        <div className="flex items-center space-x-1">
          <i className="ri-chat-1-line"></i>
          <span>{solutions} solutions</span>
        </div>
      </div>

      <div className="flex space-x-2">
        <button
          onClick={handleGenerateSolution}
          disabled={isGenerating}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap flex items-center space-x-2 disabled:opacity-50"
        >
          {isGenerating ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              <span>Generating...</span>
            </>
          ) : (
            <>
              <i className="ri-magic-line"></i>
              <span>AI Solution</span>
            </>
          )}
        </button>
        
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap"
        >
          {isExpanded ? 'Hide Details' : 'View Details'}
        </button>
      </div>

      {isExpanded && (
        <div className="mt-6 space-y-4 animate-fadeIn">
          {generatedSolution && (
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-lg border border-blue-200">
              <h4 className="font-semibold text-blue-900 mb-2 flex items-center">
                <i className="ri-lightbulb-line mr-2"></i>
                AI Generated Solution
              </h4>
              <div className="text-gray-700 whitespace-pre-wrap">
                {generatedSolution}
              </div>
            </div>
          )}
          
          {relatedQuestions.length > 0 && (
            <div className="border-t pt-4">
              <button
                onClick={() => setShowRelated(!showRelated)}
                className="text-blue-600 hover:text-blue-800 font-medium flex items-center space-x-1 cursor-pointer"
              >
                <i className="ri-question-line"></i>
                <span>Related Questions</span>
                <i className={`ri-arrow-${showRelated ? 'up' : 'down'}-s-line transition-transform`}></i>
              </button>
              
              {showRelated && (
                <div className="mt-3 space-y-2 animate-slideDown">
                  {relatedQuestions.map((question, index) => (
                    <div key={index} className="text-sm text-gray-600 hover:text-blue-600 cursor-pointer p-2 rounded hover:bg-gray-50 transition-colors">
                      • {question}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}