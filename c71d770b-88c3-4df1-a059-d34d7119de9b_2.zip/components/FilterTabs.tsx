'use client';

import { useState } from 'react';

interface FilterTabsProps {
  categories: string[];
  activeCategory: string;
  onCategoryChange: (category: string) => void;
}

export default function FilterTabs({ categories, activeCategory, onCategoryChange }: FilterTabsProps) {
  const [isAnimating, setIsAnimating] = useState(false);

  const handleCategoryClick = (category: string) => {
    if (category !== activeCategory) {
      setIsAnimating(true);
      setTimeout(() => {
        onCategoryChange(category);
        setIsAnimating(false);
      }, 150);
    }
  };

  return (
    <div className="flex flex-wrap gap-2 justify-center mb-8">
      {categories.map((category) => (
        <button
          key={category}
          onClick={() => handleCategoryClick(category)}
          className={`px-4 py-2 rounded-full transition-all duration-300 whitespace-nowrap ${
            activeCategory === category
              ? 'bg-blue-600 text-white shadow-lg transform scale-105'
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300 hover:scale-102'
          }`}
        >
          {category}
        </button>
      ))}
    </div>
  );
}